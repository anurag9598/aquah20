<?php

include'connection.php';

$name = $_POST['user'];

$email = $_POST['email'];

$mobile = $_POST['mobile'];

$message = $_POST['message'];


$sql = "INSERT INTO `userinfo` (user,email,mobile,message)
VALUES ('$name', '$email', '$mobile','$message')";

$result= mysqli_query($con,$sql);


if ($result === TRUE) {
    echo "<p style='margin:300px;'><h1>Your Message Send successfully!<h1></p>";
} else {
    echo "Error: " . $sql . "<br>" .mysqli_error($con);
}



mysqli_close($con);
?>