<?php

$con = mysqli_connect('localhost','root','','test');

if ($con) {
	echo "<h4>Thanks for Your Effort!</h4>";
}
else
{
	echo "<h4>Can't Reach</h4>";
}

?>
